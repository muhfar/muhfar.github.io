import '../css/materialize.min.css';
import '../css/style.css';
import '../js/materialize.min.js';
import '../js/sw.js';
import '../js/nav.js';
import 'regenerator-runtime';

//Image Assets
import '../assets/Bundesliga.svg';
import '../assets/FIFA World Cup.svg';
import '../assets/Premier League.svg';
import '../assets/UEFA Champions League.svg';