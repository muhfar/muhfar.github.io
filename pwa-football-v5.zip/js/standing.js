import {getStandings} from './api.js';
document.addEventListener("DOMContentLoaded", () => {
    getStandings();
})