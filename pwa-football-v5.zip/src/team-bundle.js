import '../css/materialize.min.css';
import '../css/style.css';
import '../js/sw.js';
import '../js/team.js';
import '../js/materialize.min.js';
import '../js/idb.js';